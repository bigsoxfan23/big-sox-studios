# Big Sox Studios — Production Brand Assets

Approved brand direction as of September 29, 2026.

## Identity
- Primary mascot: cream knitted sock character with visible cloth/yarn texture.
- Orange athletic stripes and orange heel/toe accents.
- Embroidered corgi patch on the upper cuff.
- Friendly expressive face/personality.
- Primary logo combines the sock/B silhouette with the Big Sox Studios wordmark.

## Folder guide
- `source/` — full-resolution PNG masters. Keep these unchanged as the archive/source files.
- `web/logo/` — optimized transparent WebP logo assets for the website.
- `web/mascot/` — optimized transparent WebP mascot poses.
- `icons/` — favicon, Apple touch icon, Android/app icons.
- `social/` — default 1200×630 Open Graph/share image.

## Recommended website paths
Copy the `web`, `icons`, and `social` contents into the Astro repository under:

```
public/brand/logo/
public/brand/mascot/
public/brand/icons/
public/brand/social/
```

Keep the original PNG masters outside the served `public/` folder if possible, or in a separate design/archive location.

## Usage
- Default light theme logo: `big-sox-studios-logo-dark.webp`
- Dark theme logo: `big-sox-studios-logo-light.webp`
- Compact mark: `big-sox-studios-mark.webp`
- Mascot default: `sock-corgi-default.webp`
- Mascot wave: `sock-corgi-wave.webp`
- Mascot positive/approval: `sock-corgi-thumbs-up.webp`
- Mascot work/loading/project context: `sock-corgi-at-work.webp`
- Site favicon: `favicon.ico` plus PNG fallbacks
- Social preview: `og-default.png`

## Brand rules
- Keep the mascot visibly textile/knitted; do not flatten it into a generic vector cartoon.
- Keep the corgi as an embroidered cuff patch, not as the entire body.
- Mascot use should be selective and purposeful.
- Preserve cream/orange/charcoal/navy palette and strong contrast.
- Do not stretch, skew, recolor, or crop the logo in a way that removes the corgi patch or sock identity.
